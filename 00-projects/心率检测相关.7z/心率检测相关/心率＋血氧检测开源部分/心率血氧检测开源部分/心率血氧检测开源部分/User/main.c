#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Key.h" 
#include "MAX30102.h"
#include "MAX30102_algorithm.h"
#include "software_IIC.h"
/* ---------------------------bilibili账号：Timmy的拨片-----------------------*/
/* ----------------按键接PA2与GND之间，测量后按下可开始下一次测量-------------*/
/* -----------------------MAX30102接线：SCL接PC14;SDA接PC13-------------------*/
/* --------------------------OLED接线：SCL接PB8;SDA接PB9----------------------*/

int main(void)
{
	OLED_Init();
	Key_Init();
	
	while (1)
	{
	
		SPO2_function();
		Heart_function();
		
	}

}
