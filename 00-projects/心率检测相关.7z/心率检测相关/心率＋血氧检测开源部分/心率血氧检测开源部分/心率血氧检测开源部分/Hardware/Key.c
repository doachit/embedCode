#include "stm32f10x.h"  // Device header


uint8_t Key_Enter = 0;	//确认键
uint8_t Key_Back = 0;	//返回键
uint8_t Key_Up = 0;		//上
uint8_t Key_Down = 0;	//下

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_2 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource2);
	
	
	EXTI_InitTypeDef EXTI_InitStructure;
	
	EXTI_InitStructure.EXTI_Line =  EXTI_Line2;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn ;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
}

/********************************************/

int8_t Key_Back_Get(void)	//返回键
{
	if(Key_Back)
	{
		Key_Back = 0;
		return 1;
	}
	return 0;
}


void Key_Reset_All(void)	//清除所有按键标志位
{
	Key_Enter = 0;
	Key_Back = 0;
	Key_Up = 0;
	Key_Down = 0;
}


void EXTI2_IRQHandler(void)
{
    if (EXTI_GetITStatus(EXTI_Line2) == SET) //返回键
	{
	/*如果出现数据乱跳的现象，可再次判断引脚电平，以避免抖动*/
		for(int i = 1; i != 720000; i++);	//延时10ms
		
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 0)
		{
			Key_Back += 1;
		}
		
		EXTI_ClearITPendingBit(EXTI_Line2);
	}
}


