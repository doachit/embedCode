#ifndef __SOFTWARE_IIC_H
#define __SOFTWARE_IIC_H

void IIC_GPIO_Init(void);
void IIC_W_SCL(uint8_t BitValue);
void IIC_W_SDA(uint8_t BitValue);
uint8_t IIC_R_SDA(void);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_SendByte(uint8_t Byte);
uint8_t IIC_ReceiveByte(void);
void IIC_SendAck(uint8_t AckBit);
uint8_t IIC_ReceiveAck(void);
void IIC_WriteReg(uint8_t slave_ID,uint8_t RegAddress, uint8_t Data);
uint8_t IIC_ReadReg(uint8_t slave_ID,uint8_t RegAddress);

#endif
