#include "stm32f10x.h"                  // Device header
#include "software_IIC.h"
#include "Delay.h"



/*****************************IIC通信协议*****************************************/

void IIC_GPIO_Init(void)
{
	uint32_t i, j;
	
	/*在初始化前，加入适量延时，待OLED供电稳定*/
	for (i = 0; i < 1000; i ++)
	{
		for (j = 0; j < 1000; j ++);
	}
	
	/*将SCL和SDA引脚初始化为开漏模式*/
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;       // SCL
 	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;       // SDA 
 	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/*释放SCL和SDA*/
	IIC_W_SCL(1);
	IIC_W_SDA(1);
}

void IIC_W_SCL(uint8_t BitValue)
{
	/*根据BitValue的值，将SCL置高电平或者低电平*/
	GPIO_WriteBit(GPIOC, GPIO_Pin_14, (BitAction)BitValue);
	
	/*如果单片机速度过快，可在此添加适量延时，以避免超出I2C通信的最大速度*/
	//...
}

void IIC_W_SDA(uint8_t BitValue)
{
	/*根据BitValue的值，将SDA置高电平或者低电平*/
	GPIO_WriteBit(GPIOC, GPIO_Pin_13, (BitAction)BitValue);
	
	/*如果单片机速度过快，可在此添加适量延时，以避免超出I2C通信的最大速度*/
	//...
}
uint8_t IIC_R_SDA(void)
{
	uint8_t BitValue;
	BitValue = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13);		//读取SDA电平
	Delay_us(10);												//延时10us，防止时序频率超过要求
	return BitValue;											//返回SDA电平
}

void IIC_Start(void)
{
	IIC_W_SDA(1);		//释放SDA，确保SDA为高电平
	IIC_W_SCL(1);		//释放SCL，确保SCL为高电平
	IIC_W_SDA(0);		//在SCL高电平期间，拉低SDA，产生起始信号
	IIC_W_SCL(0);		//起始后把SCL也拉低，即为了占用总线，也为了方便总线时序的拼接
}

void IIC_Stop(void)
{
	IIC_W_SDA(0);		//拉低SDA，确保SDA为低电平
	IIC_W_SCL(1);		//释放SCL，使SCL呈现高电平
	IIC_W_SDA(1);		//在SCL高电平期间，释放SDA，产生终止信号
}
void IIC_SendByte(uint8_t Byte)
{
	uint8_t i;
	
	/*循环8次，主机依次发送数据的每一位*/
	for (i = 0; i < 8; i++)
	{
		/*使用掩码的方式取出Byte的指定一位数据并写入到SDA线*/
		/*两个!的作用是，让所有非零的值变为1*/
		IIC_W_SDA(!!(Byte & (0x80 >> i)));
		IIC_W_SCL(1);	//释放SCL，从机在SCL高电平期间读取SDA
		IIC_W_SCL(0);	//拉低SCL，主机开始发送下一位数据
	}
	
}
uint8_t IIC_ReceiveByte(void)
{
	uint8_t i, Byte = 0x00;					//定义接收的数据，并赋初值0x00
	IIC_W_SDA(1);							//接收前，主机先确保释放SDA，避免干扰从机的数据发送
	for (i = 0; i < 8; i ++)				//循环8次，主机依次接收数据的每一位
	{
		IIC_W_SCL(1);						//释放SCL，主机机在SCL高电平期间读取SDA
		if (IIC_R_SDA() == 1){Byte |= (0x80 >> i);}	//读取SDA数据，并存储到Byte变量
														//当SDA为1时，置变量指定位为1，当SDA为0时，不做处理，指定位为默认的初值0
		IIC_W_SCL(0);						//拉低SCL，从机在SCL低电平期间写入SDA
	}
	return Byte;							//返回接收到的一个字节数据
}

void IIC_SendAck(uint8_t AckBit)
{
	IIC_W_SDA(AckBit);					//主机把应答位数据放到SDA线
	IIC_W_SCL(1);							//释放SCL，从机在SCL高电平期间，读取应答位
	IIC_W_SCL(0);							//拉低SCL，开始下一个时序模块
}

uint8_t IIC_ReceiveAck(void)
{
	uint8_t AckBit;							//定义应答位变量
	IIC_W_SDA(1);							//接收前，主机先确保释放SDA，避免干扰从机的数据发送
	IIC_W_SCL(1);							//释放SCL，主机机在SCL高电平期间读取SDA
	AckBit = IIC_R_SDA();					//将应答位存储到变量里
	IIC_W_SCL(0);							//拉低SCL，开始下一个时序模块
	return AckBit;							//返回定义应答位变量
}

void IIC_WriteReg(uint8_t slave_ID,uint8_t RegAddress, uint8_t Data)
{
	IIC_Start();						//I2C起始
	IIC_SendByte(slave_ID);	//发送从机地址，读写位为0，表示即将写入
	IIC_ReceiveAck();					//接收应答
	IIC_SendByte(RegAddress);			//发送寄存器地址
	IIC_ReceiveAck();					//接收应答
	IIC_SendByte(Data);				//发送要写入寄存器的数据
	IIC_ReceiveAck();					//接收应答
	IIC_Stop();						//I2C终止
}
uint8_t IIC_ReadReg(uint8_t slave_ID,uint8_t RegAddress)  //读取一个字节
{
	uint8_t Data;
	
	IIC_Start();						//I2C起始
	IIC_SendByte(slave_ID);	//发送从机地址，读写位为0，表示即将写入
	IIC_ReceiveAck();					//接收应答
	IIC_SendByte(RegAddress);			//发送寄存器地址
	IIC_ReceiveAck();					//接收应答
	
	IIC_Start();						//I2C重复起始
	IIC_SendByte(slave_ID | 0x01);	//发送从机地址，读写位为1，表示即将读取
	IIC_ReceiveAck();					//接收应答
	Data = IIC_ReceiveByte();			//接收指定寄存器的数据
	IIC_SendAck(1);					//发送应答，给从机非应答，终止从机的数据输出
	IIC_Stop();						//I2C终止
	
	return Data;
}


/****************************************************IIC通信协议*******************************************/


