#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Key.h" 
#include "MAX30102.h"
#include "MAX30102_algorithm.h"
#include "software_IIC.h"
/* ---------------------------bilibili账号：Timmy的拨片-----------------------*/
/* ----------------按键接PA2与GND之间，测量后按下可开始下一次测量-------------*/
/* -----------------------MAX30102接线：SCL接PC14;SDA接PC13-------------------*/
/* --------------------------OLED接线：SCL接PB8;SDA接PB9----------------------*/

int main(void)
{
	OLED_Init();
	Key_Init();
	again:
	OLED_Clear();
	OLED_ShowChinese(46,0,"血");
	OLED_ShowChinese(62,0,"氧");
	OLED_ShowChinese(78,0,"检");
	OLED_ShowChinese(94,0,"测");
	MAX30102_Init();                     //初始化MAX30102
	OLED_ShowImage(0,0,22,8,qipaoup);    //显示左上方固定的石头块
	OLED_ShowImage(0,56,22,8,qipaodown); //显示左下方固定的石头块
	OLED_Update();
	uint8_t j=128;                       //定义鱼的起始X坐标
	uint8_t ave_Count = 1;               //为了获取10个最终得到的血氧值,设置计数器,(可以更改,值越大测量时间越长，获取数据越多)
	uint16_t cal_ave[10];                //定义长度为10的数组存储10个检测数据
	uint16_t ave_Sum = 0;                //存储10个数据的和
	uint8_t cal_Sum_lock = 0;            //总和计算器锁
	while (1)
	{
		
	
		/*-------------------------移动气泡的程序逻辑------------------------------*/
		uint8_t i;
		for(i = 0;i <= 16;i++)
		{
		OLED_ClearArea(0,8,22,48);
		OLED_ShowImage(1,49-i,7,7,qipao);    
		OLED_ShowImage(1,33-i,7,7,qipao);
        if(i<17)
		{
		OLED_ShowImage(1,17-i,7,7,qipao);
		OLED_ShowImage(0,0,22,8,qipaoup);
		}	
		OLED_ShowImage(13,56-i,7,7,qipao);
		OLED_ShowImage(13,40-i,7,7,qipao);
		OLED_ShowImage(13,24-i,7,7,qipao);
		/*-------------------------移动鱼的程序逻辑------------------------------*/
		if(j<=0)
		{
			j = 128;
			OLED_ClearArea(22,49,106,15);    //清除小鱼游过后的全屏尾迹
		}
		OLED_ShowImage(j,49,15,15,Fish);
		//OLED_ClearArea(j+15,49,106,15);    //解除注释可以实时清除小鱼尾迹
		OLED_ShowImage(0,56,22,8,qipaodown); //刷新左下角石头块,让小鱼从石头快后边游过,注释后会从石头块前方游过
		j--;
		Delay_ms(5);        //控制动画移动速度
		OLED_Update();
		}
		
		if(ave_Count<=10)
		{
		    blood_Loop();
			if(SPO2dataResult != 0)
            {
			OLED_ClearArea(22,16,106,32);
			OLED_ShowChinese(54,17,"检");
	        OLED_ShowChinese(70,17,"测");
		    OLED_ShowChinese(86,17,"中");				
			cal_ave[ave_Count-1] = SPO2dataResult;
			ave_Count++;
			}else{
				    OLED_ClearArea(22,16,106,32);
				    OLED_ShowChinese(54,16,"请");
		            OLED_ShowChinese(70,16,"正");
		            OLED_ShowChinese(86,16,"确");
		            OLED_ShowChinese(54,32,"佩");
		            OLED_ShowChinese(70,32,"戴");
		            OLED_ShowChar(90,32,'!',OLED_8X16);
			     }
		}else
		{
		    ave_Count = 11;   //得到10个数据后将计数器值固定到11防止溢出
			uint8_t i;
			uint16_t min;
			for(i = 0;i<9;i++)                   //取出最小值
			{
				if(i == 0){min = cal_ave[0];}    //
			  if(cal_ave[i+1]<min) 
			  {
			  min = cal_ave[i+1];
			  }
			}
			if(cal_Sum_lock == 0)
			{
			         for(i = 0;i<10;i++)
			         {
				      ave_Sum += cal_ave[i];    //计算0个数据的和
			         }  
					 cal_Sum_lock = 1;          //和计算一次后打开锁,防止多次累加
		    }
			OLED_ClearArea(22,17,106,32);
			OLED_ShowNum(49,17,(ave_Sum-min)/9 + 3,3,OLED_15X24);  //显示最终结果
			OLED_ShowChar(96,17,0x3A,OLED_15X24);
		}
	    
		if(menu_Back_event())   //检测按键按下
        {
		 goto again;
		}
	}

}
