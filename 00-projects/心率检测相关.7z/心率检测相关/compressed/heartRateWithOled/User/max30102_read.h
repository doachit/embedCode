#ifndef MAX30102_READ_H_
#define MAX30102_READ_H_

#include "stm32f10x.h"
#include "common.h"

//heart rate
extern int32_t hrAvg;
//SPO2
extern int32_t spo2Avg;

void Init_MAX30102(void);
void ReadHeartRateSpO2(void);

#endif 

