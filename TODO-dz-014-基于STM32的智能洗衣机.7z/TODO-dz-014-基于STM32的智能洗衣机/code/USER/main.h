#include "stdio.h"//标准输入输出库
#include "string.h"//字符串库
#include "stdlib.h"//常用的系统函数库
#include "sys.h"//系统中断分组库
#include "delay.h"//延时函数库
#include "bsp_usart.h"//串口设置库
#include "timer.h"
#include "oled.h"
#include "simple_module.h"
#include "ds18b20.h"
#include "adc.h"
#include "HC_SR04.h"

void SYS_Init(void);		//系统初始化总函数	


