#include "main.h"

int gTempThresold = 30;
int gHumiThresold = 70;
void set_fan(uint8_t *data, uint16_t len);
int gLight=0;
int fanState =0;
int winState = 0;
int ledState = 0;
int mode = 0; 
float gTemp = 0.0;
float gDis = 0.0;
//Quick wash, Standard wash, Bulky item wash
enum washState{
    QUICK =0 ,
    STAND,
    BULKY
};
enum state {
    INIT = 0, //初始
    WATER = 1,//注水
    WASH, //洗衣服
    DRAIN, // 排水
    DRY,   // 甩干
    STOP, //停止工作
    START //开始工作
};

u8 start = 0;
u8 washMode = 0;
u8 gTime = 0;
int main(void) {
    u8 key;
    char oledBuf[10];
    SYS_Init();//系统初始化总函数
    while(1)   //主循环
    {
        gTemp = DS18B20_Get_Temp();
        gDis =  get_distance();

        //显示温度数据
        sprintf(oledBuf,"Temp: %.1f C    ",gTemp);	
        OLED_ShowString(0,0,(u8*)oledBuf,16,1);
        //sprintf(oledBuf,"Temp: %d C(%d)",dht11Data.temp_int,gTempThresold);	
        //OLED_ShowString(0,16,(u8*)oledBuf,16,1);
        
        sprintf(oledBuf,"Dis: %.1f cm    ",gDis);	
        OLED_ShowString(0,16,(u8*)oledBuf,16,1);
        key = KEY_Scan(1);
        
        switch (key) {
            case KEY1_PRES: {
                mode = STOP;
                start = 0;
            };break; // stop
            case KEY2_PRES: {
                start = 1;
            };break; // start
            case KEY3_PRES: {
                washMode++;
                washMode %=3;
            };break; // mode select
        }
        if (!start)
        {
         switch(washMode) {
            case QUICK: {
                gTime = 15;
                OLED_ShowString(0,32,"Mode: Quick      ",16,1);
            };break;
            case STAND: {
                gTime = 30;
                OLED_ShowString(0,32,"Mode: Standard    ",16,1);
            };break;
            case BULKY: {
                gTime = 45;
                OLED_ShowString(0,32,"Mode: Bulky item    ",16,1);
            };break;
            }
        }else{
         
            if(!Find_Sth) {// 盖子揭开了
                mode = STOP;
                start = 0;
            }else{  //
                mode = INIT;
            }
        
            switch(mode) {
                case INIT: {
                    OLED_ShowString(0,32,"State: Init     ",16,1);
                };break;
                case WATER: {
                    OLED_ShowString(0,32,"State: Adding water   ",16,1);
                };break;
                case WASH: {
                    OLED_ShowString(0,32,"State: Washing    ",16,1);
                };break;
                case DRAIN: {
                    OLED_ShowString(0,32,"State: Draining water     ",16,1);
                };break;
                case DRY: {
                    OLED_ShowString(0,32,"State: Drying    ",16,1);
                };break;
                case STOP: {
                    OLED_ShowString(0,32,"State: Stop      ",16,1);
                };break;            
            }
        }
        delay_ms(100);
        OLED_Refresh();
     }
}
/**
  * @brief  系统初始化总函数
  * @param  无
  * @retval 无
  */
void SYS_Init(void) {
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //中断优先级分组函数
    delay_init();	    							 //延时函数初始化
    delay_ms(500);	    
    USART_Module_Init(USART1,9600,ENABLE); //串口初始化为9600
    USART_RegisterCallback(USART1,set_fan);
    USART_Module_Init(USART2,9600,ENABLE); //串口初始化为9600
    USART_RegisterCallback(USART2,set_fan);
    OLED_Init();	
    DS18B20_Init(); //温度计模块
    INS_Init();     //红外传感器
    LED_Init();     //注水排水开关
    SWITCH_Init();  //洗涤甩干开关
    HC_SR04config();
    KEY_Init();
    FAN_OFF;
    LED_OFF;
    SWITCH1_OFF;
    TIM2_Int_Init(9999,7199); // 1S定时
}

#define MAX_KEY_LEN   16
#define MAX_VALUE_LEN 12

int32_t UART_ParseKeyValue(const uint8_t* data, uint16_t len, const char* target_key) 
{
    /* 变量统一在函数开始处定义 */
    char key_buf[MAX_KEY_LEN] = {0};
    char value_buf[MAX_VALUE_LEN] = {0};
    uint8_t key_idx = 0, value_idx = 0;
    uint8_t state = 0; 
    uint16_t i = 0;
    char ch = 0;
    const char* p = NULL;
    int value = 0;

    /* 参数安全检查 */
    if(data == NULL || target_key == NULL || len == 0) return 0;

    for(i = 0; i < len; i++) {
        ch = data[i];
        
        switch(state) {
            case 0:  // 跳过键前空白
                if(ch == ' ' || ch == '\t') continue;
                if(ch == ':') return 0;
                state = 1;
                /* 注意：这里没有break，继续执行case1 */

            case 1:  // 收集键
                if(ch == ':') {
                    state = 2;
                    break;
                }
                if(ch == ' ' || ch == '\t') {
                    state = 0;
                    break;
                }
                if(key_idx >= MAX_KEY_LEN-1) return 0;
                key_buf[key_idx++] = ch;
                break;
                
            case 2:  // 跳过值前空白
                if(ch == ' ' || ch == '\t') continue;
                state = 3;
                /* 继续执行case3 */

            case 3:  // 收集值
                if(ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n') {
                    state = 4;
                    break;
                }
                if(value_idx >= MAX_VALUE_LEN-1) return 0;
                value_buf[value_idx++] = ch;
                break;

            default:
                break;
        }
        if(state == 4) break;
    }
    value_buf[value_idx] = '\0';

    /* 键匹配检查 */
    if(strcmp(key_buf, target_key) != 0) return 0;

    /* 值有效性验证 */
    p = value_buf;
    if(*p == '-' || *p == '+') p++;
    while(*p != '\0') {
        if(*p < '0' || *p > '9') return 0;
        p++;
    }

    /* 转换数值 */
    value = atoi(value_buf);
    if(value > INT32_MAX) return INT32_MAX;
    if(value < INT32_MIN) return INT32_MIN;

    return (int32_t)value;
}

void set_fan(uint8_t *data, uint16_t len) {
    if(Find_str((char*)data,"tempThres")) //阈值设置
    {
        gTempThresold=UART_ParseKeyValue(data,len,"tempThres");
    }else{
        if(Find_str((char*)data,"LIGHT:ON")) //开灯
        {
            ledState = 1;
        }
        if(Find_str((char*)data,"LIGHT:OFF")) //关灯
        {
            ledState = 0;
        }
        if(Find_str((char*)data,"FAN:ON")) //开风扇
        {
            fanState = 1;
        }
        if(Find_str((char*)data,"FAN:OFF")) //关风扇
        {
            fanState = 0;
        }
        if(Find_str((char*)data,"WIN:ON")) //开窗
        {
            winState = 1;
        }
        if(Find_str((char*)data,"WIN:OFF")) //关窗
        {
            winState = 0;
        }
        if(Find_str((char*)data,"AUTO:ON")) //自动模式
        {
            mode = 1;
        }
        if(Find_str((char*)data,"AUTO:OFF")) //手动模式
        {
            mode = 0;
        }        
    }
}

void TIM_Callback(int count){
    if (start && gTime) {
        gTime--;
    }
    if(count%2){             
        //printf("#humi:%d$\n",dht11Data.humi_int);
    }
    else{
        //printf("#temp:%d$\n",dht11Data.temp_int);
    }
}
