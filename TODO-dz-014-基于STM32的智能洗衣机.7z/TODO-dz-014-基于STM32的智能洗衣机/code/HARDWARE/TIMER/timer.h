#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"

extern int nPwmPeroid;
extern int motorWorkFlag;
extern u8 timeCnt;
#define HC_SR04 1
#if !HC_SR04
void TIM3_Int_Init(u16 arr,u16 psc);
#endif
void TIM1_PWM_Init(u16 arr,u16 psc);

void TIM1_CH1_PWM_Init(u16 arr, u16 psc);
void TIM1_CH2_PWM_Init(u16 arr, u16 psc);

void TIM2_Int_Init(u16 arr,u16 psc);

void TIM_Callback(int count);
#endif
